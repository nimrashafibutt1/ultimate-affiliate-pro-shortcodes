<?php
/**
 * Plugin Name:Custom Short Code By Nimra
 * Description: This code is built by nimra shafi butt. 
 * Version: 1.0
 * Author: Nimra Shafi Butt
  */

require_once WP_PLUGIN_DIR . '/indeed-affiliate-pro/classes/UapDb.class.php';
require_once WP_PLUGIN_DIR . '/indeed-affiliate-pro/classes/MLMGetChildren.class.php';

// Styles for the MLM children tables
function mlm_children_table_styles() {
    ?>
    <style type="text/css">
      /* Defin
       /* Style for MLM Children Table Container */
.mlm-table-container {
  width: 100%;
  margin: 0 auto; /* Center the table horizontally */
}

/* Style for MLM Children Table Heading */
.mlm-table-heading {
  font-size: 20px;
  font-weight: bold;
  margin-bottom: 10px;
}

/* Style for MLM Children Table */
.mlm-table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 20px;
}

/* Style for MLM Children Table Header */
.mlm-table-header {
  background-color: #f2f2f2;
  font-weight: bold;
}

.mlm-table-header th {
  padding: 10px;
  text-align: center;
}

/* Style for MLM Children Table Rows */
.mlm-table-row:nth-child(even) {
  background-color: #f8f8f8;
}

/* Style for MLM Children Table Cells */
.mlm-table-cell {
  padding: 10px;
  text-align: left;
}

/* Hover effect for table rows */
.mlm-table-row:hover {
  background-color: #e0e0e0;
}
		/* Styling for the dashboard-stats container */
/* Base styles for larger screens */
.dashboard-stats {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    background-color: #f5f5f5;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.dashboard-stat {
    flex: 1;
    background-color: #fff;
    padding: 15px;
    margin: 10px;
    border-radius: 5px;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    text-align: center;
    transition: transform 0.3s ease;
}

/* Media query for smaller screens (e.g., mobile) */
@media (max-width: 768px) {
    .dashboard-stats {
        flex-direction: column; /* Stack items vertically */
        align-items: center; /* Center items horizontally */
    }

    .dashboard-stat {
        flex: 1;
        width: 100%; /* Make each stat take full width */
        margin: 5px 0; /* Adjust margin for spacing */
    }
}


    </style>
    <?php
}
add_action('wp_head', 'mlm_children_table_styles');

// Create a shortcode function
// Create a shortcode function
function display_mlm_children_table() {
    // Get the logged-in user's ID
    $user_id = get_current_user_id();
    
    global $wpdb;
    
    // Get the affiliate ID for the logged-in user
    $table = $wpdb->prefix . 'uap_affiliates';
    $affiliate_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE uid = %d", $user_id));

    // Check if affiliate ID is not empty before proceeding
    if (!empty($affiliate_id)) {
        // Assuming you have already instantiated the MLMGetChildren class
        $mlm = new MLMGetChildren($affiliate_id);
        $children = $mlm->get_results();

        // Create tables for each level
        $tables = array();

        // Iterate through the children and organize them by level
        foreach ($children as $child) {
            $level = $child['level'];

            if (!isset($tables[$level])) {
                // Create a new table for the current level if it doesn't exist
                $tables[$level] = '<h2 class="mlm-table-heading">Level ' . $level . ' Users</h2><table class="mlm-table">';
                $tables[$level] .= '<tr class="mlm-table-header"><th>ID</th><th>Parent</th><th>Level</th><th>Username</th><th>Email</th><th>Full Name</th><th>Amount</th></tr>';
            }

            // Add the child data to the corresponding level table
            $tables[$level] .= '<tr class="mlm-table-row">';
            $tables[$level] .= '<td class="mlm-table-cell">' . $child['id'] . '</td>';
            $tables[$level] .= '<td class="mlm-table-cell">' . $child['parent'] . '</td>';
            $tables[$level] .= '<td class="mlm-table-cell">' . $child['level'] . '</td>';
            $tables[$level] .= '<td class="mlm-table-cell">' . $child['username'] . '</td>';
            $tables[$level] .= '<td class="mlm-table-cell">' . $child['email'] . '</td>';
            $tables[$level] .= '<td class="mlm-table-cell">' . $child['full_name'] . '</td>';
            $tables[$level] .= '<td class="mlm-table-cell">' . $child['amount_value'] . '</td>';
            $tables[$level] .= '</tr>';
        }

        // Close all level tables
        foreach ($tables as &$table) {
            $table .= '</table>';
        }

        // Combine all level tables into one output
        $output = implode('', $tables);

        return $output;
    } else {
        // Handle the case when the affiliate ID is empty (e.g., display a message)
        return 'You are not an affiliate yet.';
    }
}

add_shortcode('mlm_children_table', 'display_mlm_children_table');
//second function 
//
//
// Include the class file if not already included



//3rd 
//
function transactions_shortcode($atts) {
    // Get the logged-in user's ID
    $user_id = get_current_user_id();

    global $wpdb;

    // Get the affiliate ID for the logged-in user
    $table = $wpdb->prefix . 'uap_affiliates';
    $affiliate_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE uid = %d", $user_id));

    // Parse shortcode attributes
    $atts = shortcode_atts(array(
        'limit' => -1,
        'offset' => -1,
        'order_by' => '',
        'order_type' => 'create_date',
    ), $atts);

    // Get attributes
    $limit = intval($atts['limit']);
    $offset = intval($atts['offset']);
    $order_by = sanitize_text_field($atts['order_by']);
    $order_type = sanitize_text_field($atts['order_type']);

    // Instantiate your class (replace 'Your_Class_Name' with the actual class name)
    $uap_db_class = new UapDb();

    // Call the method to get transactions
    $transactions = $uap_db_class->get_transactions(
        $affiliate_id,
        $limit,
        $offset,
        FALSE, // Do not count
        $order_by,
        $order_type
    );

    // Process and format the transactions as needed
    $output = '';

    if (!empty($transactions)) {
        foreach ($transactions as $transaction) {
            // Format and display each transaction here
            $output .= '<div class="transaction">';
            $output .= '<p>Transaction ID: ' . $transaction['id'] . '</p>';
            $output .= '<p>Affiliate ID: ' . $transaction['affiliate_id'] . '</p>';
            // Add more details as needed
            $output .= '</div>';
        }
    } else {
        $output = 'No transactions found.';
    }

    return $output;
}

// Register the shortcode
add_shortcode('transactions', 'transactions_shortcode');
//4th
//
function stats_for_dashboard_shortcode() {
    // Instantiate your class (replace 'Your_Class_Name' with the actual class name)
    $uap_class_instance = new UapDb(); // Replace with your actual class name

    // Call the method to get stats for the dashboard
    $stats_data = $uap_class_instance->stats_for_dashboard();

    // Process and format the stats data as needed
    $output = '';

    if (!empty($stats_data)) {
        $output .= '<div class="dashboard-stats">';

        // Each statistic is wrapped in its own div with a unique class
        $output .= '<div class="dashboard-stat">';
        $output .= '<h3>Affiliates</h3>';
        $output .= '<p class="stat-value">' . $stats_data['affiliates'] . '</p>';
        $output .= '</div>';

        $output .= '<div class="dashboard-stat">';
        $output .= '<h3>Unpaid Payments Value</h3>';
        $output .= '<p class="stat-value">' . $stats_data['unpaid_payments_value'] . '</p>';
        $output .= '</div>';

        $output .= '<div class="dashboard-stat">';
        $output .= '<h3>Referrals</h3>';
        $output .= '<p class="stat-value">' . $stats_data['referrals'] . '</p>';
        $output .= '</div>';

        $output .= '<div class="dashboard-stat">';
        $output .= '<h3>Top Rank</h3>';
        $output .= '<p class="stat-value">' . $stats_data['top_rank'] . '</p>';
        $output .= '</div>';

        // Add more stats as needed

        $output .= '</div>';
    } else {
        $output = 'No dashboard stats available.';
    }

    return $output;
}

// Register the shortcode
add_shortcode('dashboard_stats', 'stats_for_dashboard_shortcode');
//shortcode for the referrals detail
//
//
function referrals_table_shortcode() {
    // Instantiate your class (replace 'Your_Class_Name' with the actual class name)
   


    // Generate the HTML table with CSS classes
    $output = '<div class="mlm-table-container">'; // Use mlm-table-container class
    $output .= '<table class="mlm-table referrals-table">'; // Use mlm-table and referrals-table classes
    $output .= '<thead>';
    $output .= '<tr class="mlm-table-header">'; // Use mlm-table-header class for table header row
    $output .= '<th class="mlm-table-cell">ID</th>'; // Use mlm-table-cell class for table header cell

    $output .= '<th class="mlm-table-cell">Amount</th>'; // Use mlm-table-cell class for table header cell
    $output .= '<th class="mlm-table-cell">Date</th>';

	// Use mlm-table-cell class for table header cell
    $output .= '<th class="mlm-table-cell">Username</th>'; // Use mlm-table-cell class for table header cell
    $output .= '</tr>';
    $output .= '</thead>';
    $output .= '<tbody>';

    if (!empty($referrals_data)) {
        foreach ($referrals_data as $referral) {
            $output .= '<tr class="mlm-table-row">'; // Use mlm-table-row class for table rows
            $output .= '<td class="mlm-table-cell">' . $referral['id'] . '</td>'; // Use mlm-table-cell class for table cells
            $output .= '<td class="mlm-table-cell">' . $referral['amount'] . '</td>'; // Use mlm-table-cell class for table cells
            $output .= '<td class="mlm-table-cell">' . $referral['date'] . '</td>'; // Use mlm-table-cell class for table cells
            $output .= '<td class="mlm-table-cell">' . $referral['username'] . '</td>'; // Use mlm-table-cell class for table cells
            $output .= '</tr>';
        }
    } else {
        $output .= '<tr class="mlm-table-row"><td class="mlm-table-cell" colspan="4">No referral data available.</td></tr>'; // Use mlm-table-cell class for table cell
    }

    $output .= '</tbody>';
    $output .= '</table>';
    $output .= '</div>';

    return $output;
}

// Register the shortcode
add_shortcode('referrals_table', 'referrals_table_shortcode');
//referal report 
//
// Create a shortcode function for displaying referral reports
// Create a shortcode function for displaying referral reports
// 
// Create a shortcode function for displaying referral reports
// Create a shortcode function for displaying referral reports
// Create a shortcode function for displaying referral reports
function display_referral_reports_shortcode($atts) {
    // Get the affiliate ID from shortcode attributes or use the current user's ID
     // Get the logged-in user's ID
    $user_id = get_current_user_id();

    global $wpdb;

    // Get the affiliate ID for the logged-in user
    $table = $wpdb->prefix . 'uap_affiliates';
    $affiliate_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE uid = %d", $user_id));
	
	 $uap_class_instance = new UapDb(); // Replace with your actual class name

    // Call the method to get referral data
    $referrals_data = $uap_class_instance->get_referrals();
	   $user_id = get_current_user_id();



    // Instantiate your class (replace 'Your_Class_Name' with the actual class name)
    $uap_class_instance = new UapDb(); // Replace with your actual class name

    // Get the affiliate ID for the logged-in user
    $affiliate_id = $uap_class_instance->get_affiliate_id_by_wpuid($user_id);



    // Instantiate your class (replace 'Your_Class_Name' with the actual class name)
    $uap_class_instance = new UapDb(); // Replace with your actual class name

    // Call the method to get referral reports
    $referral_reports = $uap_class_instance->getReferralsReports($affiliate_id);

    // Format the referral reports with CSS classes
    $output = '<div class="dashboard-stats">'; // Use the same class as in stats_for_dashboard_shortcode

    $output .= '<div class="dashboard-stat">';
    $output .= '<h3>Total Earnings</h3>';
    $output .= '<p class="stat-value">$' . number_format($referral_reports['total_earnings'], 2) . '</p>';
    $output .= '</div>';


    $output .= '<div class="dashboard-stat">';
    $output .= '<h3>Total Referrals</h3>';
    $output .= '<p class="stat-value">' . $referral_reports['total_referrals'] . '</p>';
    $output .= '</div>';

    $output .= '<div class="dashboard-stat">';
    $output .= '<h3>Refused Referrals</h3>';
    $output .= '<p class="stat-value">' . $referral_reports['refuse_referrals'] . '</p>';
    $output .= '</div>';

    $output .= '<div class="dashboard-stat">';
    $output .= '<h3>Unverified Referrals</h3>';
    $output .= '<p class="stat-value">' . $referral_reports['unverified_referrals'] . '</p>';
    $output .= '</div>';

    $output .= '<div class="dashboard-stat">';
    $output .= '<h3>Verified Referrals</h3>';
    $output .= '<p class="stat-value">' . $referral_reports['verified_referrals'] . '</p>';
    $output .= '</div>';

    $output .= '<div class="dashboard-stat">';
    $output .= '<h3>Visits</h3>';
    $output .= '<p class="stat-value">' . $referral_reports['visits'] . '</p>';
    $output .= '</div>';

    $output .= '</div>';

    return $output;
}

// Register the shortcode with the name 'referral_reports'
add_shortcode('referral_reports', 'display_referral_reports_shortcode');
function Bonus_Report_Shortcode($atts) {
    // Get the affiliate ID from shortcode attributes or use the current user's ID
    $user_id = get_current_user_id();

    global $wpdb;

    // Instantiate your class (replace 'Your_Class_Name' with the actual class name)
    $uap_class_instance = new UapDb(); // Replace with your actual class name

    // Get the affiliate ID for the logged-in user
    $affiliate_id = $uap_class_instance->get_affiliate_id_by_wpuid($user_id);

    $bonus_query = $wpdb->prepare(
        "SELECT SUM(amount) as total_amount FROM {$wpdb->prefix}uap_referrals WHERE affiliate_id = %d AND reference_details = %s",
        $affiliate_id,
        'Bonus'
    );

    // Execute the query
    $bonus_results = $wpdb->get_results($bonus_query);

    // Check if there are results
    if (!empty($bonus_results)) {
        // Access the sum using the alias 'total_amount'
        $total_amount = $bonus_results[0]->total_amount;

        // Display the sum in your HTML output
        $output = '<div class="dashboard-stat">';
        $output .= '<h3>Bonus</h3>';
        $output .= '<p class="stat-value">$' . number_format($total_amount, 2) . '</p>'; // Format the sum as currency
        $output .= '</div>';
    } else {
        // Handle the case when there are no results (e.g., display a message)
        $output = '<div class="dashboard-stat">';
        $output .= '<h3>Bonus</h3>';
        $output .= '<p class="stat-value">$0.00</p>'; // Display $0.00 or any other default message
        $output .= '</div>';
    }

    return $output;
}

// Register the shortcode with the name 'Bonus_reports'
add_shortcode('Bonus_reports', 'Bonus_Report_Shortcode');
